/* Contains only uninitialized data which end up in BSS section. */

char dummy[10];
