/* Tests loading of a shared library which contains only BSS section. */

#include <stdio.h>

int main(void)
{
   printf("PASS\n");
   return 0;
}
