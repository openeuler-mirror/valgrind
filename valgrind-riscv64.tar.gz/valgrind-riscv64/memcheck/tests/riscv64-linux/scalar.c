/* TODO Implement. */
#include "scalar.h"
int main(void) { return 0; }
