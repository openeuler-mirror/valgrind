int main() {
   int x;
   if (x) return 1;
   return 0;
}
