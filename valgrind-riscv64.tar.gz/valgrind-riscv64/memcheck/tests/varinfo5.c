
extern void varinfo5_main ( void );

int main ( void ) {
  varinfo5_main();
  return 0;
}
