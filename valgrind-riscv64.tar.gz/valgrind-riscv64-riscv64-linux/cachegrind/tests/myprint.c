#include <stdio.h>

void myprint(void)
{
   puts("This is myprint!");
}
